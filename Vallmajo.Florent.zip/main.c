#include <stdio.h>
#include <stdbool.h>

int swap_function (ar[],i, posmin, size) {
    int value;
    int x, pos1, pos2, lenght;
    printf("what is the size of your array ?");
    scanf("%d", &size);
    for (int i = 0; i < size; i++)
    {
        printf("Enter a value");
        scanf("%d", &value);
        ar[i] = value;
    }
    printf("enter pos 1 of your swap");
    scanf("%d", &pos1);
    printf("Enter pos 2 of your swap");
    scanf("%d", &pos2);
    if (pos1 <= 0 || pos1 > lenght || pos2 <= 0 || pos2 > lenght)
        return false;
    x = ar[pos1];
    ar[pos1] = ar[pos2];
    ar[pos2] = x;
    return true;
}

int min_function(ar[], size)
{
    int posmin, value;
    printf("what is the size of your array ?");
    scanf("%d", &size);
    for (int i = 0; i < size; i++)
    {
        printf("Enter a value");
        scanf("%d", &value);
        ar[i] = value;
    }

    if (size == 0)
        return 0;
    posmin = 1;
    for (int i = 2; i <= size; i++)
        if (ar[i] < ar[posmin])
            posmin = i;
    return posmin;
}

int sort_function(size)
{
    int posmin, value, ar[100];
    printf("what is the size of your array ?");
    scanf("%d", &size);
    for (int i = 0; i < size; i++)
    {
        printf("Enter a value");
        scanf("%d", &value);
        ar[i] = value;
    }
    for (int i = 0; i< size-1; i++)
    {
        posmin = min_function( (ar + i - 1), size - i + 1);
        if (posmin != i)
            swap_function(ar, i, posmin, size - i + 1);
    }

}

main ()
{

}
